from pyb import Pin

class BumpSensor:
    """
    A class to represent a bump sensor.

    Attributes:
        pin (Pin): The GPIO pin the bump sensor is connected to.
        triggered (bool): State indicating if the sensor has been triggered.
    """

    def __init__(self, pin_name):
        """
        Initialize the bump sensor.

        Args:
            pin_name (str): The name of the GPIO pin (e.g., 'B8', 'Y2').
        """
        self.pin = Pin(pin_name, Pin.IN, Pin.PULL_UP)
        self.triggered = False

    def is_bumped(self):
        """
        Check if the bump sensor is activated.

        If the sensor is activated, it permanently sets the triggered state to True.

        Returns:
            bool: True if the sensor was activated, False otherwise.
        """
        if self.pin.value() == 0:  # Active low
            self.triggered = True
        return self.triggered

    def wait_for_bump(self):
        """
        Block execution until the bump sensor is pressed.

        Prints "Bump detected!" when triggered.
        """
        print("Waiting for bump...")
        while True:
            if self.is_bumped():
                print("Bump detected!")
                break

