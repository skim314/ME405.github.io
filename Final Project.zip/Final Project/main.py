# Import necessary modules
from encoder import Encoder
from motor import MotorDriver
from i2c import BNO055
from BumpSensor import BumpSensor
from LineSensor import LineTrackingSensorArray  # Your line sensor library
import cotask
import task_share
import time

# Define shared variables for inter-task communication
right_motor_speed_share = task_share.Share('h', thread_protect=False, name="Right Motor Speed Share")
right_motor_position_share = task_share.Share('h', thread_protect=False, name="Right Motor Position Share")
left_motor_speed_share = task_share.Share('h', thread_protect=False, name="Left Motor Speed Share")
left_motor_position_share = task_share.Share('h', thread_protect=False, name="Left Motor Position Share")
yaw_share = task_share.Share('h', thread_protect=False, name="Yaw Share")
angular_velocity_share = task_share.Share('f', thread_protect=False, name="Angular Velocity Share")

cumulative_yaw_share = task_share.Share('f', thread_protect=False, name="Cumulative Yaw")
right_motor_duty_cycle_share = task_share.Share('h', thread_protect=False, name="Right Motor Duty Cycle Share")
left_motor_duty_cycle_share = task_share.Share('h', thread_protect=False, name="Left Motor Duty Cycle Share")

def imu_task(shares):
    imu = shares[0]  # IMU object
    yaw_share = shares[1]  # Shared variable for yaw
    angular_velocity_share = shares[2]  # Shared variable for angular velocity

    while True:
        yaw = imu.get_heading()  # Read yaw
        yaw_rate = imu.get_yaw_rate()  # Read yaw rate

        yaw_share.put(int(yaw))
        angular_velocity_share.put(yaw_rate)

        yield 0  # Yield control to allow other tasks to run

def encoder_task(shares):
    encoder, speed_share, position_share = shares

    while True:
        encoder.update()

        # Update speed and position
        speed = encoder.get_speed_rpm()
        position = encoder.get_position_radians()

        speed_share.put(int(speed))  # Update shared speed
        position_share.put(int(position))  # Update shared position

        yield 0  # Yield control to allow other tasks to run

def motor_task(shares):
    motor, duty_cycle_share = shares

    while True:
        duty_cycle = duty_cycle_share.get()
        if duty_cycle > 0:
            motor.set_direction(forward=True)
        else:
            motor.set_direction(forward=False)

        motor.set_effort(abs(duty_cycle))
        yield 0  # Yield control to allow other tasks to run

def closed_loop_control(shares):
    (right_motor_duty_cycle_share, left_motor_duty_cycle_share, line_sensor, bump_sensor) = shares

    # Gains for Proportional, Integral, and Derivative Control
    Kp_line = 10  # Increased Proportional gain for more aggressive corrections
    Ki_line = 0.75  # Slightly higher Integral gain to handle cumulative errors
    Kd_line = 5.0  # Increased Derivative gain to better anticipate changes

    base_duty_cycle = 10  # Slightly increased base speed for quicker response

    # Initialize control terms
    integral_error = 0
    last_error = 0
    last_time = time.time()

    # Track the last known line detection time
    last_line_time = time.time()

    # Initialize motors to base duty cycle
    right_motor_duty_cycle_share.put(base_duty_cycle)
    left_motor_duty_cycle_share.put(base_duty_cycle)

    while True:
        current_time = time.time()

        # Check bump sensor
        if bump_sensor.is_bumped():  # Assuming bump_sensor has an `is_triggered` method
            # Run motors backward for 0.5 seconds
            right_motor_duty_cycle_share.put(-base_duty_cycle)
            left_motor_duty_cycle_share.put(-base_duty_cycle)
            time.sleep(0.5)

            # Stop motors
            right_motor_duty_cycle_share.put(0)
            left_motor_duty_cycle_share.put(0)
            time.sleep(0.1)

            # Resume normal operation
            right_motor_duty_cycle_share.put(base_duty_cycle)
            left_motor_duty_cycle_share.put(base_duty_cycle)
            continue

        # Read line sensor data
        sensor_values = line_sensor.detect_all_surfaces()

        # Check if line is lost
        if sum(sensor_values) == len(sensor_values):  # All sensors detect white (line lost)
            if current_time - last_line_time > 0.1:  # If lost for more than 0.1 seconds
                # Stop motors briefly
                right_motor_duty_cycle_share.put(0)
                left_motor_duty_cycle_share.put(0)
                time.sleep(0.1)

                # Resume movement with base duty cycle
                right_motor_duty_cycle_share.put(base_duty_cycle)
                left_motor_duty_cycle_share.put(base_duty_cycle)
                continue
        else:
            # Update the last known line detection time
            last_line_time = current_time

            # Calculate error based on weighted positions of sensors
            error = (sensor_values[0] * 2 + sensor_values[1] * 1 + sensor_values[3] * -1 + sensor_values[4] * -2)

            # Reset integral error if a new dash is detected (middle sensor sees black)
            if sensor_values[2] == 0:  # Assuming middle sensor index is 2
                integral_error = 0

            # Derivative and integral error calculations
            delta_time = current_time - last_time if last_time else 1.0
            derivative_error = (error - last_error) / delta_time if delta_time > 0 else 0
            integral_error += error * delta_time
            integral_error = max(min(integral_error, 50), -50)  # Increased cap to allow more cumulative effect

            # Calculate correction using PID
            correction = (Kp_line * error) + (Ki_line * integral_error) + (Kd_line * derivative_error)

            # Adjust motor duty cycles
            right_duty_cycle = base_duty_cycle + correction
            left_duty_cycle = base_duty_cycle + correction

            # Saturate duty cycles to [0, 100]
            right_duty_cycle = max(min(right_duty_cycle, 100), 0)
            left_duty_cycle = max(min(left_duty_cycle, 100), 0)

            # Update motor duty cycles
            right_motor_duty_cycle_share.put(int(right_duty_cycle))
            left_motor_duty_cycle_share.put(int(left_duty_cycle))

            # Save the error and time for the next iteration
            last_error = error
            last_time = current_time

        yield 0  # Yield control to allow other tasks to run


def communication_task(shares):
    (right_motor_speed_share, right_motor_position_share, left_motor_speed_share, 
     left_motor_position_share, angular_velocity_share, yaw_share, cumulative_yaw_share, line_sensor) = shares

    while True:
        # Retrieve the latest shared values for both motors
        right_speed = right_motor_speed_share.get()
        right_position = right_motor_position_share.get()
        left_speed = left_motor_speed_share.get()
        left_position = left_motor_position_share.get()
        yaw_rate = angular_velocity_share.get()
        yaw = yaw_share.get()
        cumulative_yaw = cumulative_yaw_share.get()

        # Read line sensor data
        sensor_values = line_sensor.detect_all_surfaces()

        # Print information for debugging
        print(f"Right Motor Speed: {right_speed}, Position: {right_position}")
        print(f"Left Motor Speed: {left_speed}, Position: {left_position}")
        print(f"IMU Yaw Rate: {yaw_rate} degrees/sec")
        print(f"IMU Yaw: {yaw} degrees")
        print(f"Cumulative Yaw: {cumulative_yaw} degrees")
        print(f"Line Sensor Values: {sensor_values}")

        yield 0  # Yield control to allow other tasks to run

if __name__ == '__main__':
    print("Starting tasks...")

    # Initialize IMU
    imu = BNO055(1, 'PA5')

    # Initialize motors, encoders, and line sensors
    mot_Right = MotorDriver('PA8', 'PB10', 'PC7', 8)  # Right motor pins
    enc_Right = Encoder(2, 'PA0', 'PA1', 1024)  # Right encoder channels
    mot_Left = MotorDriver('PB3', 'PA10', 'PA9', 1)  # Left motor pins
    enc_Left = Encoder(3, 'PB4', 'PB5', 1024)  # Left encoder channels
    line_sensor = LineTrackingSensorArray(['PC1', 'PC0', 'PC2', 'PC3', 'PA4'], 3.3)  # Updated ADC pins
    bump_sensor = BumpSensor('PC11')

    # Enable motors and zero encoders
    mot_Right.enable()
    enc_Right.zero()
    mot_Left.enable()
    enc_Left.zero()

    right_motor_duty_cycle_share.put(50)  # Example: 50% duty cycle
    left_motor_duty_cycle_share.put(50)

    # Create tasks
    task_imu = cotask.Task(imu_task, name="IMUTask", priority=3, period=100, 
                           shares=(imu, yaw_share, angular_velocity_share))
    task_right_encoder = cotask.Task(encoder_task, name="RightEncoderTask", priority=2, period=100, 
                                     shares=(enc_Right, right_motor_speed_share, right_motor_position_share))
    task_left_encoder = cotask.Task(encoder_task, name="LeftEncoderTask", priority=2, period=100, 
                                    shares=(enc_Left, left_motor_speed_share, left_motor_position_share))
    task_right_motor = cotask.Task(motor_task, name="RightMotorTask", priority=3, period=50, 
                                   shares=(mot_Right, right_motor_duty_cycle_share))
    task_left_motor = cotask.Task(motor_task, name="LeftMotorTask", priority=3, period=50, 
                                  shares=(mot_Left, left_motor_duty_cycle_share))
    task_closed_loop_control = cotask.Task(closed_loop_control,name="ClosedLoopControl",priority=4,period=50,shares=(right_motor_duty_cycle_share, left_motor_duty_cycle_share, line_sensor,bump_sensor))


    task_communication = cotask.Task(communication_task, name="CommunicationTask", priority=1, period=500, 
                                      shares=(right_motor_speed_share, right_motor_position_share, 
                                              left_motor_speed_share, left_motor_position_share, 
                                              angular_velocity_share, yaw_share, cumulative_yaw_share, 
                                              line_sensor))

    # Add tasks to cotask scheduler
    cotask.task_list.append(task_imu)
    cotask.task_list.append(task_right_encoder)
    cotask.task_list.append(task_left_encoder)
    cotask.task_list.append(task_right_motor)
    cotask.task_list.append(task_left_motor)
    cotask.task_list.append(task_closed_loop_control)
    cotask.task_list.append(task_communication)

    # Start the task scheduler
    while True:
        try:
            cotask.task_list.pri_sched()
        except KeyboardInterrupt:
            break

    print('\n' + str(cotask.task_list))
    print(task_share.show_all())