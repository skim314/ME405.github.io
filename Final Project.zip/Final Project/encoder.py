from pyb import Timer, Pin  # Import inside the class
import time  # Make sure to import time here

class Encoder:
    def __init__(self, timer_num, CH1_pin, CH2_pin, counts_per_revolution, AR=0xFFFF, PS=0):

        self.counts_per_revolution = counts_per_revolution  # Counts per revolution of the encoder
        self.last_time = time.ticks_ms()  # Track time for speed calculation
        self.current_time = self.last_time
        self.time_interval = 0  # In seconds

        # Initialize timer
        self.tim = Timer(timer_num, period=AR, prescaler=PS)
        self.tim.counter(0)  # Reset counter

        # Set up channels for encoder mode
        self.CH1 = self.tim.channel(1, pin=Pin(CH1_pin), mode=Timer.ENC_AB)
        self.CH2 = self.tim.channel(2, pin=Pin(CH2_pin), mode=Timer.ENC_AB)

        # Internal variables
        self.old_count = 0
        self.new_count = 0
        self.delta = 0
        self.total_position = 0

    def update(self):
        """Update encoder readings and handle overflow/underflow."""
        self.new_count = (self.tim.counter())  # Make sure it's an integer
        self.delta = self.new_count - self.old_count
        self.old_count = self.new_count

        # Handle overflow/underflow
        AR = self.tim.period()
        if self.delta > (AR + 1) / 2:
            self.delta -= (AR + 1)
        elif self.delta < -(AR + 1) / 2:
            self.delta += (AR + 1)

        # Update total position (in counts)
        self.total_position += self.delta

        # Calculate time interval since the last update
        self.current_time = time.ticks_ms()
        self.time_interval = time.ticks_diff(self.current_time, self.last_time) / 1000  # In seconds
        self.last_time = self.current_time  # Update the last_time for the next update

    def get_position_radians(self):
        """Return the position in radians."""
        return (self.total_position / (self.counts_per_revolution)) * 2 * 3.14159  # Ensure the division is done in float

    def get_speed_rpm(self):
        """Return the speed in RPM (Revolutions Per Minute)."""
        if self.time_interval == 0:
            return 0  # Avoid division by zero
        # Calculate RPM using the formula
        rpm = (self.delta * 60) / (self.counts_per_revolution * self.time_interval)
        return rpm

    def get_position(self):
        """Return the cumulative position in counts."""
        return self.total_position

    def get_delta(self):
        """Return the latest change in position (counts)."""
        return self.delta

    def zero(self):
        """Reset the encoder readings to zero."""
        self.old_count = 0
        self.new_count = 0
        self.delta = 0
        self.total_position = 0
        self.tim.counter(0)
        print("Encoder zeroed")

    def set_ar(self, AR):
        """Set a new auto-reload value."""
        self.tim.period(AR)
        print(f"Auto-reload (AR) set to: {AR}")

    def set_ps(self, PS):
        """Set a new prescaler value."""
        self.tim.prescaler(PS)
        print(f"Prescaler (PS) set to: {PS}")
