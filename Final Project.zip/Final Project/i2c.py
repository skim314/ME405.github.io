import struct
import time
import pyb

# BNO055 I2C addresses and registers
I2C_ADDR = 0x28  # I2C address for the BNO055
OPR_MODE_REG = 0x3D  # Register for operation mode
CALIB_STAT_REG = 0x35  # Calibration status register
CALIB_DATA_REG = 0x55  # Calibration data register
BNO055_EULER_H = 0x1A  # Euler angle high byte register
BNO055_GYRO_RATE_REG = 0x14  # Angular velocity register

# MODES
MODE_NDOF = 0x0C  # Data from gyroscope, accelerometer, magnetometer
MODE_IMU = 0x08  # IMU mode
MODE_COMPASS = 0x20  # Compass mode
MODE_CONFIG = 0x00  # Config mode for calibration operations

# Ensure this file contains the complete and correct BNO055 class definition
class BNO055:
    
    def __init__(self, i2c_bus_num, rst_pin_name=None):
        self.i2c = pyb.I2C(i2c_bus_num, pyb.I2C.MASTER, baudrate=100000)
        self.address = I2C_ADDR
        if rst_pin_name:
            self.rst_pin = pyb.Pin(rst_pin_name, pyb.Pin.OUT_PP)
            self.reset_device()
        else:
            self.rst_pin = None
        self.set_mode(MODE_NDOF)
        
    def set_mode(self, mode):
        self.i2c.mem_write(mode, self.address, OPR_MODE_REG)
        time.sleep(0.03)

    def reset_device(self):
        """Reset the BNO055 using the reset pin."""
        if self.rst_pin:
            self.rst_pin.low()
            time.sleep(0.01)  # Hold reset low for 10 ms
            self.rst_pin.high()
            time.sleep(0.65)  # Allow time for the sensor to restart

    def get_calibration_status(self):
        """
        Retrieve and parse the calibration status byte from the IMU.
        :return: A tuple (sys, gyro, accel, mag) indicating calibration status (0-3 for each).
        """
        status = self.i2c.mem_read(1, self.address, CALIB_STAT_REG)
        if status:
            status = status[0]
            sys = (status >> 6) & 0x03
            gyro = (status >> 4) & 0x03
            accel = (status >> 2) & 0x03
            mag = status & 0x03
            return sys, gyro, accel, mag
        else:
            raise RuntimeError("Failed to read calibration status")

    def read_calibration_coefficients(self):
        """
        Retrieve the calibration coefficients from the IMU as binary data.
        :return: Binary data of calibration coefficients (22 bytes).
        """
        self.set_mode(MODE_CONFIG)  # Switch to CONFIG mode before reading calibration data
        data = self.i2c.mem_read(22, self.address, CALIB_DATA_REG)
        self.set_mode(MODE_NDOF)  # Return to NDOF mode
        return data

    def write_calibration_coefficients(self, data):
        """
        Write calibration coefficients back to the IMU from pre-recorded binary data.
        :param data: Binary data of calibration coefficients (22 bytes).
        """
        if len(data) != 22:
            raise ValueError("Calibration data must be 22 bytes.")
        self.set_mode(MODE_CONFIG)  # Switch to CONFIG mode before writing calibration data
        for i in range(len(data)):
            self.i2c.mem_write(data[i:i+1], self.address, CALIB_DATA_REG + i)
        self.set_mode(MODE_NDOF)  # Return to NDOF mode

    def get_euler_angles(self):
        """
        Read and return Euler angles (heading, roll, pitch) from the IMU.
        :return: A tuple (heading, roll, pitch) in degrees.
        """
        euler_data = self.i2c.mem_read(6, self.address, BNO055_EULER_H)
        
        # Unpack the data and return the angles
        heading, roll, pitch = struct.unpack('<hhh', euler_data)
        return heading / 16.0, roll / 16.0, pitch / 16.0

    def get_heading(self):
        """
        Retrieve only the heading (yaw) angle.
        :return: Heading angle in degrees.
        """
        return self.get_euler_angles()[0]

    def get_angular_velocity(self):
        """
        Read and return angular velocities (gyro rates for x, y, z).
        :return: A dictionary with keys 'gyro_x', 'gyro_y', 'gyro_z', representing angular velocity in degrees/second.
        """
        gyro_data = self.i2c.mem_read(6, self.address, BNO055_GYRO_RATE_REG)
        gyro_x = struct.unpack('<h', gyro_data[0:2])[0] / 16.0
        gyro_y = struct.unpack('<h', gyro_data[2:4])[0] / 16.0
        gyro_z = struct.unpack('<h', gyro_data[4:6])[0] / 16.0
        return {'gyro_x': gyro_x, 'gyro_y': gyro_y, 'gyro_z': gyro_z}

    def get_yaw_rate(self):
        """
        Retrieve only the yaw rate (gyro rate around the Z-axis).
        :return: Yaw rate in degrees/second.
        """
        return self.get_angular_velocity()['gyro_z']