class MotorDriver:
    def __init__(self, enable_pin, direction_pin, effort_pin, timer_num):
        from pyb import Pin, Timer
        # Set up pins for enable and direction
        self.EN = Pin(enable_pin, mode=Pin.OUT_PP)
        self.DIR = Pin(direction_pin, mode=Pin.OUT_PP)

        # Set up the effort pin as a PWM output using a timer channel
        self.PWM = Timer(timer_num, freq=20000)  # 20 kHz frequency
        self.EFFORT = self.PWM.channel(2, Timer.PWM, pin=Pin(effort_pin))

    def enable(self):
        """Enable the motor by setting the enable pin high."""
        self.EN.high()
        print("Motor enabled.")

    def disable(self):
        """Disable the motor by setting the enable pin low."""
        self.EN.low()
        print("Motor disabled.")

    def set_direction(self, forward=True):
        """Set motor direction."""
        if forward:
            self.DIR.low()  # Assuming low is forward
        else:
            self.DIR.high()   # Assuming high is reverse

    def set_effort(self, effort):
        """Set the motor effort as a PWM duty cycle percentage."""
        if effort < 0:
            effort = 0  # Ensure no negative effort values
        elif effort > 100:
            effort = 100  # Ensure effort does not exceed 100%

        self.EFFORT.pulse_width_percent(effort)
