from pyb import Pin, ADC

class LineTrackingSensor:
    def __init__(self, pin_name, black_voltage=0.3, white_voltage=2.0):
        """
        Initialize a line tracking sensor.

        :param pin_name: Name of the pin connected to the sensor.
        :param black_voltage: Voltage threshold for detecting black surface.
        :param white_voltage: Voltage threshold for detecting white surface.
        """
        self.adc = ADC(Pin(pin_name))
        self.threshold = int(((black_voltage + white_voltage) / 2) / 3.3 * 4095)  # Convert to ADC value

    def detect_surface(self):
        """
        Detect if the surface is black or white and output 1 or 0.

        :return: 1 if black, 0 if white.
        """
        return 1 if self.adc.read() <= self.threshold else 0


class LineTrackingSensorArray:
    def __init__(self, pin_names, black_voltage=0.3, white_voltage=2.0):
        """
        Initialize an array of line tracking sensors.

        :param pin_names: List of pin names connected to the sensors.
        :param black_voltage: Voltage threshold for detecting black surface.
        :param white_voltage: Voltage threshold for detecting white surface.
        """
        self.sensors = [LineTrackingSensor(pin_name, black_voltage, white_voltage) for pin_name in pin_names]

    def detect_all_surfaces(self):
        """
        Detect the surface color for all sensors and output 1 or 0 for each.

        :return: List of integers (1 for black, 0 for white).
        """
        return [sensor.detect_surface() for sensor in self.sensors]
